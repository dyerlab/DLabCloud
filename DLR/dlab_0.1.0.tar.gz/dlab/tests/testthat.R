library(testthat)
library(dlab)

test_check("dlab")
